{
    'name': 'Auto Internal User',
    'version': '18.0.1.0.0',
    'summary': 'Convierte usuarios del portal en usuarios internos con acceso a inventario y ventas',
    'category': 'User',
    'author': 'Custom',
    'depends': ['base', 'website', 'stock', 'sale_management'],
    'data': [],
    'installable': True,
    'application': False,
}
