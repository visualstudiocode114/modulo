from odoo import models, api

class ResUsers(models.Model):
    _inherit = 'res.users'

    @api.model
    def create(self, vals):
        user = super().create(vals)

        # Referencias a grupos
        group_portal = self.env.ref('base.group_portal')
        group_internal = self.env.ref('base.group_user')
        group_inventory_user = self.env.ref('stock.group_stock_user')
        group_sales_user = self.env.ref('sales_team.group_sale_salesman')

        # Si el usuario es portal -> convertirlo en interno + inventario + ventas
        if group_portal in user.groups_id:
            user.write({
                'groups_id': [
                    (3, group_portal.id),            # Quitar portal
                    (4, group_internal.id),          # Agregar usuario interno
                    (4, group_inventory_user.id),    # Agregar permisos inventario
                    (4, group_sales_user.id),        # Agregar permisos ventas
                ]
            })

        return user
