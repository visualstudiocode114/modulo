.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.png
   :alt: License: AGPL-3
   :target: https://www.gnu.org/licenses/agpl-3.0-standalone.html

========================
Website Sale Send Policy
========================

Módulo para permitir al cliente seleccionar la política de envío preferida en
el checkout.

Autor
~~~~~~~
.. image:: https://trey.es/logo.png
   :alt: License: Trey Kilobytes de Soluciones SL
`Trey Kilobytes de Soluciones SL <https://www.trey.es>`_
